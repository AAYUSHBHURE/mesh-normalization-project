# Sample .obj files go here
# Download mesh files from the provided link and place them in this folder

# You can find free .obj files from sources like:
# - https://github.com/alecjacobson/common-3d-test-models
# - http://graphics.stanford.edu/data/3Dscanrep/
# - Any other 3D model repository

# Expected format: .obj files with vertices and faces
